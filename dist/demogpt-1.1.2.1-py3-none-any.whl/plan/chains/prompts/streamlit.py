human_template = """
Create a streamlit function that having the following features by using only streamlit library and python's standard library:
When you use text_input, please use key attribute to differentiate the text inputs.

instruction:{instruction}
===========================
inputs:{inputs}
===========================
function name:{function_name}
===========================
Streamlit Function:
"""
