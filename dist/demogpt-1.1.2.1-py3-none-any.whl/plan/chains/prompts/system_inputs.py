human_template = """
Which inputs should a system get from the user to do the instruction below
{instruction}
"""
