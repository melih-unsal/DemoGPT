human_template = """
Explain how to combine the tasks in a way that 
a streamlit code generator can generate a streamlit code to do the instruction.
You have an instruction and the task list below:

Instruction:{instruction}
===========================
Task List:{task_list}
===========================
Explanation:
"""
