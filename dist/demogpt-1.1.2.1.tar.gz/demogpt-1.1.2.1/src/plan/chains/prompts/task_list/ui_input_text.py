human_template = """
Write a streamlit textfield or textarea together with a button code depending on the instruction below:
Suppose that, streamlit has been imported by "import streamlit as st" so you don't need to import it.

Assign the taken input to the variable called "{variable}"

Instruction:{instruction}
Streamlit Code:
"""